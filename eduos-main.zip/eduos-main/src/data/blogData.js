// data/blogData.js
const blogData = [
	{
		id: 1,
		image: "/blog.jpg",
		date: "November 13, 2024",
		comments: "3 COMMENTS",
		title:
			"Top Benefits of Using Software for School Management in 2024 Top Benefits of Using Software for School Management in 2024",
		content:
			"This is the detailed content of the first blog post. lorem ipsum Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.",
	},
	{
		id: 2,
		image: "/blog.jpg",
		date: "November 15, 2024",
		comments: "5 COMMENTS",
		title: "How Technology is Shaping Education Globally",
		content:
			"This is the detailed content of the second blog post. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.",
	},
	{
		id: 3,
		image: "/blog.jpg",
		date: "November 18, 2024",
		comments: "10 COMMENTS",
		title: "The Future of E-Learning in Developing Nations",
		content:
			"This is the detailed content of the third blog post. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum deserunt, saepe similique atque quo ipsam neque officia amet tempore suscipit laboriosam ex, culpa corrupti deleniti iusto ad animi nulla optio.",
	},
];

export default blogData;
